﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace dz1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Введите первое число: ");
            double number1 = Convert.ToDouble(Console.ReadLine());
            Console.Write("Введите второе число: ");
            double number2 = Convert.ToDouble(Console.ReadLine());
            double summ = number1 + number2;
            double minus = number1 - number2;
            double multiplication = number1 * number2;
            double division = number1 / number2;
            Console.WriteLine($"Сумма: {summ}  Вычитание: {minus}  Умножение: {multiplication}  Деление: {division}");
        }
    }
}
