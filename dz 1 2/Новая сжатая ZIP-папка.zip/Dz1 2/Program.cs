﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dz1_2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Введите цену товара: ");
            double price = Convert.ToDouble(Console.ReadLine());
            Console.Write("Введите количество товара: ");
            int count = Convert.ToInt16(Console.ReadLine());
            Console.Write("Введите скидку на товар: ");
            double sale = Convert.ToDouble(Console.ReadLine());
            double sale1 = (sale / 100) * price * count;
            double summ = price * count - sale1;
            Console.WriteLine($"Итоговая сумма: {summ}p");
        }
    }
}
