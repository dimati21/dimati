﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace гладиаторы
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string password;
            double health, armor, damage, realdamage, health1, armor1, damage1, realdamage1;
            int i = 3;
            string realpassword = "P@ssw0rd";
            do
            {
                Console.ResetColor();
                Console.WriteLine("Логин: login");
                Console.Write("Пароль: ");
                password = Console.ReadLine();
                if (realpassword == password)
                {
                    Console.ForegroundColor = ConsoleColor.Green;
                    Console.WriteLine("Вход выполнен");
                    break;
                }
                else
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    i--;
                    Console.WriteLine($"Неверный пароль, осталось попыткок: {i}");
                }
            }
            while (i != 0);
            Console.ResetColor();
            Random rnd = new Random();
            Console.Write("Введите номер задания: ");
            int task = Convert.ToInt16(Console.ReadLine());
            switch (task)
            {
                case 1:
                    Console.Write("Введите количество здоровья гладиатора: ");
                    health = Convert.ToDouble(Console.ReadLine());
                    Console.Write("Введите количество брони гладиатора: ");
                    armor = Convert.ToDouble(Console.ReadLine());
                    damage = rnd.Next(1, 100);
                    Console.WriteLine($"Урон гладиатору: {damage}");
                    realdamage = damage * (1 - armor / 500);
                    Console.WriteLine($"Урон с учетом брони: {realdamage}");
                    if (health <= realdamage)
                    {
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine("Гладиатор умер");
                        Console.ResetColor();
                    }
                    else
                    {
                        health = health - realdamage;
                        Console.WriteLine($"Здоровье гладиатора: {health}");
                    }
                    break;
                case 2:
                    health = rnd.Next(1, 100);
                    Console.ForegroundColor = ConsoleColor.Green;
                    Console.WriteLine($"Здоровье первого гладиатора: {health}");
                    armor = rnd.Next(1, 100);
                    Console.ForegroundColor = ConsoleColor.Blue;
                    Console.WriteLine($"Броня первого гладиатора: {armor}");
                    health1 = rnd.Next(1, 100);
                    Console.ForegroundColor = ConsoleColor.Green;
                    Console.WriteLine($"Здоровье второго гладиатора: {health1}");
                    armor1 = rnd.Next(1, 100);
                    Console.ForegroundColor = ConsoleColor.Blue;
                    Console.WriteLine($"Броня второго гладиатора: {armor1}");
                    damage = rnd.Next(1, 100);
                    Console.ResetColor();
                    Console.WriteLine($"Урон первому гладиатору: {damage}");
                    damage1 = rnd.Next(1, 100);
                    Console.WriteLine($"Урон второму гладиатору: {damage1}");
                    Console.ForegroundColor = ConsoleColor.Red;
                    realdamage = damage * (1 - armor / 500);
                    Console.WriteLine($"Урон первому с учетом брони: {realdamage}");
                    realdamage1 = damage1 * (1 - armor1 / 500);
                    Console.WriteLine($"Урон второму с учетом брони: {realdamage1}");
                    health = health - realdamage;
                    health1 = health1 - realdamage1;
                    if (health > health1)
                    {
                        Console.ForegroundColor = ConsoleColor.Green;
                        Console.WriteLine($"Победил первый гладиатор со здоровьем: {health}");
                    }
                    else
                    {
                        Console.ForegroundColor = ConsoleColor.Yellow;
                        Console.WriteLine($"Победил второй гладиатор со здоровьем: {health1}");
                    }
                    Console.ResetColor();
                    break;
                default:                    
                    Console.WriteLine("Неверно выбрано задание");
                    break;
            }
        }   
    }
}
